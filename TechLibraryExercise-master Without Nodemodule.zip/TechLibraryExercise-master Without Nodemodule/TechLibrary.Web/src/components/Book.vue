<template>

    <div >
        <b-card :title="book.title"
                :img-src="book.thumbnailUrl"
                img-alt="Image"
                img-top
                tag="article"
                style="max-width: 30rem;"
                class="mb-2"
                v-if="book && !(mode ==='add' || mode ==='edit')">
            <b-card-text>
                {{ book.descr }}
                
            </b-card-text>

    
        </b-card>
        

        <div>
            <b-card   :title="cardTitle"
                      v-if="mode ==='add' || mode ==='edit'">
               <b-form >
      <b-form-group
        id="input-group-1"
        label="Book Title"
        label-for="input-1"
      >
        <b-form-input
          id="input-1"
          v-model="book.title"
          type="text"
          required
          placeholder="Enter Book Title"
        ></b-form-input>
      </b-form-group>

      <b-form-group id="input-group-2" label="Book Description" label-for="input-2">
        <b-form-input
          id="input-2"
          v-model="book.descr"
          required
          placeholder="Enter Description"
        ></b-form-input>
      </b-form-group>
      <div>
<b-button type="reset"  variant="danger" v-if="mode ==='add'">Reset</b-button>
  <b-button type="submit"  variant="success" v-if="mode ==='add' || mode ==='edit'" v-on:click="onSubmit(book)">{{ (mode ==='add') ? 'Save' : 'Update' }}</b-button>
  <b-button to="/" variant="primary">Back</b-button>
  </div>
    </b-form>
    <b-alert variant="success" show v-if="showSuccess === true">Success Alert</b-alert>
            </b-card>
        </div>
        <div>
  <b-button to="/" variant="primary" v-if="!(mode ==='add' || mode ==='edit')">Back</b-button>
   <router-link :to="{ path: `/book/${id}/edit`}" v-if="!(mode ==='add' || mode ==='edit')">Edit Book</router-link>
   
</div>
        
    </div>
    
</template>

<script>
    import axios from 'axios';

    export default {
        name: 'Book',
        props: ["id", "mode"],
        
        data: () => ({
            book: {
            id: 0,
            descr: null,
            title: null
            },
            text: null,
            cardTitle: null,
            showSuccess: false
        }),
        methods: {
            onSubmit: (book) => {
                if(!!book.title && !!book.descr){
                        axios.post(`https://localhost:5001/books/save`, book).then(() =>{
                           this. showSuccess =  true;
                        });
                        
                } else{
                    alert('Fill mandatory fields');
                }
            
            }
        },
        mounted() {
            this.cardTitle = (this.mode === 'add') ? 'Add Book Details' : 'Edit Book Details';
            axios.get(`https://localhost:5001/books/${this.id}`)
                 .then(response => {
                     this.book = response.data;
            });
        }
    }
</script>