﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using TechLibrary.Contracts.Requests;
using TechLibrary.Data;
using TechLibrary.Domain;
using TechLibrary.Models;

namespace TechLibrary.Services
{
    public interface IBookService
    {
        Task<List<Book>> GetBooksAsync();
        Task<Book> GetBookByIdAsync(int bookid);

        int SaveBook(BookRequest bookRequest);
    }

    public class BookService : IBookService
    {
        private readonly DataContext _dataContext;
        private readonly IMapper _mapper;
        public BookService(DataContext dataContext, IMapper mapper)
        {
            _dataContext = dataContext;
            _mapper = mapper;
        }

        public async Task<List<Book>> GetBooksAsync()
        {
            var queryable = _dataContext.Books.AsQueryable();

            return await queryable.ToListAsync();
        }

        public async Task<Book> GetBookByIdAsync(int bookid)
        {
            return await _dataContext.Books.SingleOrDefaultAsync(x => x.BookId == bookid);
        }

        public int SaveBook(BookRequest bookRequest)
        {
            Book book = new Book();
            int isSaved = 0;
            book.Title = bookRequest.Title;
            book.ISBN = bookRequest.ISBN;
            book.LongDescr = bookRequest.Descr;
            book.ShortDescr = bookRequest.Descr;
            book.PublishedDate = DateTime.Now.ToShortDateString();
            book.ThumbnailUrl = bookRequest.ThumbnailUrl;

            if (bookRequest.BookId <= 0)
            {
                _dataContext.Books.Add(book);

            }
            else
            {
                this._dataContext.Entry(book).State = EntityState.Modified;
                this._dataContext.Books.Attach(book);
                //this._dataContext.Entry(book).Property("BookId").IsModified = true;
            }

            isSaved = _dataContext.SaveChanges();

            //_mapper.Map<BookRequest, Book>(bookRequest);

            return isSaved;
            // return await _dataContext.Books.SingleOrDefaultAsync(x => x.BookId == bookid);

        }
    }
}
